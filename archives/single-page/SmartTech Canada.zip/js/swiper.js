const swiper = new Swiper(".mySwiperProjects", {
  slidesPerView: 2,
  spaceBetween: 120,
  speed: 800,
  autoplay: {
    delay: 3000,
    disableOnInteraction: false,
  },
  pagination: {
    el: ".swiper-rojects-pagination",
    clickable: true,
  },
});

const swiperReviews = new Swiper(".mySwiperReviews", {
  slidesPerView: 1,
  spaceBetween: 15,
  speed: 800,
  autoplay: {
    delay: 3000,
    disableOnInteraction: false,
  },
  pagination: {
    el: ".swiper-reviews-pagination",
    clickable: true,
  },
});
