function cookiePopup() {
  const popup = document.getElementById("cookie-popup");
  const acceptBtn = document.getElementById("acceptCookies");

  if (!localStorage.getItem("cookieAccepted")) {
    popup.classList.remove("hide");
  }

  acceptBtn.addEventListener("click", function () {
    localStorage.setItem("cookieAccepted", true);
    popup.classList.add("hide");
  });
}

setTimeout(cookiePopup, 5000);
