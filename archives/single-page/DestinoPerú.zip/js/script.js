const contactForm = document.querySelector(".contact-form");

contactForm.addEventListener("submit", (e) => {
  e.preventDefault();
  window.location.href = "./thank-you.html";
});

document.addEventListener("DOMContentLoaded", function () {
  const cookiePopup = document.getElementById("cookiePopup");
  const acceptCookies = document.getElementById("acceptCookies");

  if (!localStorage.getItem("cookiesAcceptedDestinoPerú")) {
    cookiePopup.style.display = "block";
  }

  acceptCookies &&
    acceptCookies.addEventListener("click", function () {
      localStorage.setItem("cookiesAcceptedDestinoPerú", "true");
      cookiePopup.style.display = "none";
    });
});

AOS.init({
  duration: 1800,
});
