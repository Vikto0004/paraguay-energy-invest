document.addEventListener("DOMContentLoaded", function () {
  var popup = document.getElementById("cookie-popup");
  var acceptBtn = document.getElementById("acceptCookies");
  if (!localStorage.getItem("cookieAccepted")) {
    popup.classList.remove("hide");
  }
  acceptBtn.addEventListener("click", function () {
    localStorage.setItem("cookieAccepted", true);
    popup.classList.add("hide");
  });
});
