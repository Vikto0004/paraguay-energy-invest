const ctx = document.getElementById("resourceInvestmentChart").getContext("2d");

const gradientMining = ctx.createLinearGradient(0, 0, 0, 400);
gradientMining.addColorStop(0, "rgba(54, 162, 235, 0.5)");
gradientMining.addColorStop(1, "rgba(54, 162, 235, 0)");

const gradientOil = ctx.createLinearGradient(0, 0, 0, 400);
gradientOil.addColorStop(0, "rgba(255, 99, 132, 0.5)");
gradientOil.addColorStop(1, "rgba(255, 99, 132, 0)");

const gradientGas = ctx.createLinearGradient(0, 0, 0, 400);
gradientGas.addColorStop(0, "rgba(255, 205, 86, 0.5)");
gradientGas.addColorStop(1, "rgba(255, 205, 86, 0)");

const data = {
  labels: ["2019", "2020", "2021", "2022", "2023", "2024"],
  datasets: [
    {
      label: "Inversiones en minería (millones €)",
      data: [20, 35, 50, 80, 100, 120],
      backgroundColor: gradientMining,
      borderColor: "rgba(54, 162, 235, 1)",
      borderWidth: 2,
      pointBackgroundColor: "rgba(54, 162, 235, 1)",
      pointRadius: 6,
      pointHoverRadius: 8,
      fill: true,
    },
    {
      label: "Inversiones en petróleo (millones €)",
      data: [15, 25, 45, 70, 90, 110],
      backgroundColor: gradientOil,
      borderColor: "rgba(255, 99, 132, 1)",
      borderWidth: 2,
      pointBackgroundColor: "rgba(255, 99, 132, 1)",
      pointRadius: 6,
      pointHoverRadius: 8,
      fill: true,
    },
    {
      label: "Inversiones en gas (millones €)",
      data: [10, 20, 30, 50, 75, 95],
      backgroundColor: gradientGas,
      borderColor: "rgba(255, 205, 86, 1)",
      borderWidth: 2,
      pointBackgroundColor: "rgba(255, 205, 86, 1)",
      pointRadius: 6,
      pointHoverRadius: 8,
      fill: true,
    },
  ],
};

new Chart(ctx, {
  type: "line",
  data: data,
  options: {
    responsive: true,
    plugins: {
      tooltip: {
        enabled: true,
        backgroundColor: "rgba(0, 0, 0, 0.7)",
        titleColor: "#fff",
        bodyColor: "#fff",
      },
    },
    scales: {
      x: {
        grid: { color: "rgba(200, 200, 200, 0.3)" },
        ticks: { color: "#333" },
      },
      y: {
        beginAtZero: true,
        grid: { color: "rgba(200, 200, 200, 0.3)" },
        ticks: { color: "#333" },
      },
    },
  },
});
