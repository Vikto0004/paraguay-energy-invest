setTimeout(function () {
  if (localStorage.getItem("cookieAcceptedWebCrafters")) {
    document.getElementById("cookie-popup").style.display = "none";
  } else {
    const cookiePopup = document.getElementById("cookie-popup");
    cookiePopup.style.display = "flex";
  }
}, 5000);

document.getElementById("accept-cookie").addEventListener("click", function () {
  const cookiePopup = document.getElementById("cookie-popup");
  cookiePopup.style.display = "none";

  localStorage.setItem("cookieAcceptedWebCrafters", "true");
});
