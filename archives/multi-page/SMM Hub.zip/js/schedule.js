const ctx = document.getElementById("smmGrowthChart").getContext("2d");

const gradientAds = ctx.createLinearGradient(0, 0, 0, 400);
gradientAds.addColorStop(0, "rgba(75, 192, 192, 0.5)");
gradientAds.addColorStop(1, "rgba(75, 192, 192, 0)");

const gradientTraining = ctx.createLinearGradient(0, 0, 0, 400);
gradientTraining.addColorStop(0, "rgba(255, 159, 64, 0.5)");
gradientTraining.addColorStop(1, "rgba(255, 159, 64, 0)");

const gradientConsulting = ctx.createLinearGradient(0, 0, 0, 400);
gradientConsulting.addColorStop(0, "rgba(153, 102, 255, 0.5)");
gradientConsulting.addColorStop(1, "rgba(153, 102, 255, 0)");

const data = {
  labels: ["2019", "2020", "2021", "2022", "2023", "2024"],
  datasets: [
    {
      label: "Расходы бизнеса на SMM-рекламу (млн $)",
      data: [8, 15, 30, 50, 70, 90],
      backgroundColor: gradientAds,
      borderColor: "rgba(75, 192, 192, 1)",
      borderWidth: 2,
      pointBackgroundColor: "rgba(255, 99, 132, 1)",
      pointRadius: 6,
      pointHoverRadius: 8,
      fill: true,
    },
    {
      label: "Рост спроса на обучение SMM",
      data: [5, 10, 18, 25, 35, 50],
      backgroundColor: gradientTraining,
      borderColor: "rgba(255, 159, 64, 1)",
      borderWidth: 2,
      pointBackgroundColor: "rgba(255, 205, 86, 1)",
      pointRadius: 6,
      pointHoverRadius: 8,
      fill: true,
    },
    {
      label: "SMM-консалтинг: количество запросов",
      data: [3, 7, 12, 20, 28, 40],
      backgroundColor: gradientConsulting,
      borderColor: "rgba(153, 102, 255, 1)",
      borderWidth: 2,
      pointBackgroundColor: "rgba(153, 102, 255, 1)",
      pointRadius: 6,
      pointHoverRadius: 8,
      fill: true,
    },
  ],
};

new Chart(ctx, {
  type: "line",
  data: data,
  options: {
    responsive: true,
    plugins: {
      tooltip: {
        enabled: true,
        backgroundColor: "rgba(0, 0, 0, 0.7)",
        titleColor: "#fff",
        bodyColor: "#fff",
      },
    },
    scales: {
      x: {
        grid: { color: "rgba(200, 200, 200, 0.3)" },
        ticks: { color: "#333" },
      },
      y: {
        beginAtZero: true,
        grid: { color: "rgba(200, 200, 200, 0.3)" },
        ticks: { color: "#333" },
      },
    },
  },
});
