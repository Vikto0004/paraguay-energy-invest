const phoneInput = document.querySelector("#phone");
const form = document.getElementById("contact-form");

form.addEventListener("submit", function (event) {
  event.preventDefault();
  window.location.href = "thank-you.html";
});

intlTelInput(phoneInput, {
  initialCountry: "auto",
  geoIpLookup: (callback) => {
    fetch("https://ipinfo.io/json")
      .then((res) => res.json())
      .then((data) => callback(data.country))
      .catch(() => callback("us"));
  },
  utilsScript:
    "https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.8/js/utils.min.js",
});
phoneInput.classList.add("iti");
