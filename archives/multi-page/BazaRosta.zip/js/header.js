const headerBtnBurger = document.querySelector(".header-nav-btn");
const headerMobileMenu = document.querySelector(".header-mobil-wrapper");
const headerMobileMenuClose = document.querySelector(".header-mobil-btn");

headerBtnBurger.addEventListener("click", () => {
  headerMobileMenu.classList.add("header-mobil-active");
});

headerMobileMenuClose.addEventListener("click", () => {
  headerMobileMenu.classList.remove("header-mobil-active");
});
