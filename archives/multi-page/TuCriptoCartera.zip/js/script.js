const cookiePopup = document.getElementById("cookiePopup");
const acceptCookies = document.getElementById("acceptCookies");

setTimeout(() => {
  if (!localStorage.getItem("cookiesAcceptedTuCriptoCartera")) {
    cookiePopup.style.display = "block";
  }
}, 5000);

acceptCookies.addEventListener("click", function () {
  localStorage.setItem("cookiesAcceptedTuCriptoCartera", "true");
  cookiePopup.style.display = "none";
});
