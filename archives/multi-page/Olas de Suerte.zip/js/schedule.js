const ctx = document.getElementById("cruiseStatsChart").getContext("2d");

const gradientPassengers = ctx.createLinearGradient(0, 0, 0, 400);
gradientPassengers.addColorStop(0, "rgba(54, 162, 235, 0.5)");
gradientPassengers.addColorStop(1, "rgba(54, 162, 235, 0)");

const gradientEntertainment = ctx.createLinearGradient(0, 0, 0, 400);
gradientEntertainment.addColorStop(0, "rgba(255, 99, 132, 0.5)");
gradientEntertainment.addColorStop(1, "rgba(255, 99, 132, 0)");

const gradientSpending = ctx.createLinearGradient(0, 0, 0, 400);
gradientSpending.addColorStop(0, "rgba(255, 205, 86, 0.5)");
gradientSpending.addColorStop(1, "rgba(255, 205, 86, 0)");

const data = {
  labels: ["2019", "2020", "2021", "2022", "2023", "2024"],
  datasets: [
    {
      label: "Número de pasajeros (miles)",
      data: [50, 45, 60, 75, 90, 110],
      backgroundColor: gradientPassengers,
      borderColor: "rgba(54, 162, 235, 1)",
      borderWidth: 2,
      pointBackgroundColor: "rgba(54, 162, 235, 1)",
      pointRadius: 6,
      pointHoverRadius: 8,
      fill: true,
    },
    {
      label: "Popularidad del entretenimiento (%)",
      data: [60, 65, 70, 75, 85, 90],
      backgroundColor: gradientEntertainment,
      borderColor: "rgba(255, 99, 132, 1)",
      borderWidth: 2,
      pointBackgroundColor: "rgba(255, 99, 132, 1)",
      pointRadius: 6,
      pointHoverRadius: 8,
      fill: true,
    },
    {
      label: "Gasto promedio por pasajero (€)",
      data: [500, 520, 550, 580, 600, 650],
      backgroundColor: gradientSpending,
      borderColor: "rgba(255, 205, 86, 1)",
      borderWidth: 2,
      pointBackgroundColor: "rgba(255, 205, 86, 1)",
      pointRadius: 6,
      pointHoverRadius: 8,
      fill: true,
    },
  ],
};

new Chart(ctx, {
  type: "line",
  data: data,
  options: {
    responsive: true,
    plugins: {
      tooltip: {
        enabled: true,
        backgroundColor: "rgba(0, 0, 0, 0.7)",
        titleColor: "#fff",
        bodyColor: "#fff",
      },
    },
    scales: {
      x: {
        grid: { color: "rgba(200, 200, 200, 0.3)" },
        ticks: { color: "#333" },
      },
      y: {
        beginAtZero: true,
        grid: { color: "rgba(200, 200, 200, 0.3)" },
        ticks: { color: "#333" },
      },
    },
  },
});
