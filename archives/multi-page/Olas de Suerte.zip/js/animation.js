if (document.querySelector(".advantages-list")) {
  gsap.from(".advantages-list", {
    duration: 2,
    scale: 0,
    opacity: 0,
    ease: "back.out(1.7)",
    scrollTrigger: {
      trigger: ".advantages-list",
      start: "top 80%",
    },
  });
}

if (document.querySelector(".contact-wrapper")) {
  gsap.from(".contact-wrapper", {
    duration: 2, // Тривалість анімації
    x: "100%", // Початкова позиція за межами екрана зліва
    opacity: 0, // Початкова прозорість
    ease: "power3.out", // Плавне завершення анімації
    scrollTrigger: {
      trigger: ".contact-wrapper", // Тригер для запуску анімації
      start: "top 80%", // Коли елемент досягає 80% від верхньої частини вікна
      end: "top 30%", // Коли елемент досягає 30% від верхньої частини вікна
    },
  });
}

if (document.querySelector(".contact-map")) {
  gsap.from(".contact-map", {
    duration: 2, // Тривалість анімації
    x: "-100%", // Початкова позиція за межами екрана справа
    opacity: 0, // Початкова прозорість
    ease: "power3.out", // Плавне завершення анімації
    scrollTrigger: {
      trigger: ".contact-map", // Тригер для запуску анімації
      start: "top 80%", // Коли елемент досягає 80% від верхньої частини вікна
      end: "top 30%", // Коли елемент досягає 30% від верхньої частини вікна
    },
  });
}
