document.addEventListener("DOMContentLoaded", function () {
  const cookiePopup = document.getElementById("cookiePopup");
  const acceptCookies = document.getElementById("acceptCookies");

  if (!localStorage.getItem("cookiesAccepted Finovate UK")) {
    cookiePopup.style.display = "block";
  }

  acceptCookies &&
    acceptCookies.addEventListener("click", function () {
      localStorage.setItem("cookiesAccepted Finovate UK", "true");
      cookiePopup.style.display = "none";
    });
});
