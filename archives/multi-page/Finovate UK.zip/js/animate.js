AOS.init({
  duration: 1800,
});

const elements = document.querySelectorAll(".about-item");

function triggerAllAnimations() {
  elements.forEach((el) => el.classList.add("aos-animate"));
}

function removeAllAnimations() {
  setTimeout(() => {
    elements.forEach((el) => el.removeAttribute("data-aos"));
    elements.forEach((el) => el.classList.add("aos-no-animate"));
  }, 2600);
}

if (elements) {
  const observer = new IntersectionObserver(
    (entries) => {
      for (let entry of entries) {
        if (entry.isIntersecting) {
          triggerAllAnimations();
          removeAllAnimations();
          break;
        }
      }
    },
    { threshold: 0.5 }
  );

  elements.forEach((el) => observer.observe(el));
}
