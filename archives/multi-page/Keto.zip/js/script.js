const cookiePopup = document.getElementById("cookiePopup");
const acceptCookies = document.getElementById("acceptCookies");

setTimeout(() => {
  if (!localStorage.getItem("cookiesAcceptedKeto")) {
    cookiePopup.style.display = "block";
  }
}, 5000);

acceptCookies.addEventListener("click", function () {
  localStorage.setItem("cookiesAcceptedKeto", "true");
  cookiePopup.style.display = "none";
});
